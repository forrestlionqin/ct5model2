export PIPELINE_YAML_PATH=semantic_search.yaml
# 使用端口号 8891 启动模型服务
python rest_api/application.py 8891

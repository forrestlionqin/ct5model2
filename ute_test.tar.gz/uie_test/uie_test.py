from pprint import pprint
from paddlenlp import Taskflow

schema = ['Subject']
ie_en = Taskflow('information_extraction', schema=schema, model='uie-base-en')
pprint(ie_en('Customers under the condition that balance is bigger than 20 and TRB is smaller than 1000 and age is older than 50'))


schema = ['Person']
ie_en = Taskflow('information_extraction', schema=schema, model='uie-base-en')
pprint(ie_en("Tom is Apple's CEO and John is GE's CEO"))